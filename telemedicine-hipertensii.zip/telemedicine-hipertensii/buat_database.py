"""
Membuat database SQLite TensiSehat dari berkas yang sudah ada.
Tidak mengubah app.py, Dataset_Hipertensi.csv, maupun riwayat.json (hanya membaca).

Jalankan dari folder proyek:   python database/buat_database.py
Hasil: database/tensisehat.db  dan  database/tensisehat.sql
"""
import ast, csv, json, re, sqlite3
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
DB, SQL = OUT / "tensisehat.db", OUT / "tensisehat.sql"


def konstanta_app():
    """Ambil konstanta (LEAF, TANDA, SARAN, EDU) dari app.py tanpa menjalankan aplikasi."""
    tree = ast.parse((BASE / "app.py").read_text("utf-8"))
    out = {}
    for n in tree.body:
        if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name):
            if n.targets[0].id in ("LEAF", "TANDA", "SARAN", "EDU", "AKURASI"):
                out[n.targets[0].id] = ast.literal_eval(n.value)
    return out


SCHEMA = """
PRAGMA foreign_keys = ON;
DROP VIEW  IF EXISTS v_distribusi_kategori;
DROP TABLE IF EXISTS dataset_hipertensi;
DROP TABLE IF EXISTS riwayat_skrining;
DROP TABLE IF EXISTS model_decision_tree;
DROP TABLE IF EXISTS saran;
DROP TABLE IF EXISTS tanda_bahaya;
DROP TABLE IF EXISTS edukasi;

-- Isi Dataset_Hipertensi.csv (200 data, nama kolom sama dengan CSV)
CREATE TABLE dataset_hipertensi (
  ID_Pasien TEXT PRIMARY KEY,
  Usia INTEGER NOT NULL,
  Jenis_Kelamin TEXT NOT NULL,
  IMT REAL NOT NULL,
  Aktivitas_Fisik TEXT NOT NULL,
  Merokok TEXT NOT NULL,
  Riwayat_Keluarga_Hipertensi TEXT NOT NULL,
  Konsumsi_Garam TEXT NOT NULL,
  Tingkat_Stres TEXT NOT NULL,
  Tekanan_Darah_Sistolik INTEGER NOT NULL,
  Tekanan_Darah_Diastolik INTEGER NOT NULL,
  Kategori_Risiko TEXT NOT NULL CHECK (Kategori_Risiko IN ('Rendah','Sedang','Tinggi'))
);

-- Isi riwayat.json (nama kolom sama dengan kunci JSON)
CREATE TABLE riwayat_skrining (
  id INTEGER PRIMARY KEY,
  tgl TEXT NOT NULL,
  nama TEXT NOT NULL,
  usia INTEGER NOT NULL,
  jk TEXT NOT NULL,
  imt REAL NOT NULL,
  sis INTEGER NOT NULL,
  dia INTEGER NOT NULL,
  level TEXT NOT NULL CHECK (level IN ('Rendah','Sedang','Tinggi')),
  probs TEXT NOT NULL,          -- JSON {"Rendah":..,"Sedang":..,"Tinggi":..}
  path TEXT NOT NULL,           -- JSON daftar aturan pohon
  n INTEGER NOT NULL,
  tanda TEXT NOT NULL,          -- JSON daftar tanda bahaya
  naik INTEGER NOT NULL,        -- 1 bila dinaikkan aturan pengaman
  bp TEXT NOT NULL,
  aktivitas TEXT, merokok TEXT, riwayat TEXT, garam TEXT, stres TEXT   -- isi objek "gaya"
);
CREATE INDEX idx_riwayat_nama ON riwayat_skrining(nama);

-- Model Decision Tree RapidMiner (LEAF di app.py)
CREATE TABLE model_decision_tree (
  kategori TEXT PRIMARY KEY,
  aturan TEXT NOT NULL,
  jumlah_rendah INTEGER NOT NULL,
  jumlah_sedang INTEGER NOT NULL,
  jumlah_tinggi INTEGER NOT NULL
);

CREATE TABLE saran (id INTEGER PRIMARY KEY AUTOINCREMENT, kategori TEXT NOT NULL, urutan INTEGER NOT NULL, isi TEXT NOT NULL);
CREATE TABLE tanda_bahaya (id INTEGER PRIMARY KEY AUTOINCREMENT, nama TEXT NOT NULL UNIQUE);
CREATE TABLE edukasi (id INTEGER PRIMARY KEY AUTOINCREMENT, judul TEXT NOT NULL, isi TEXT NOT NULL);

CREATE VIEW v_distribusi_kategori AS
  SELECT Kategori_Risiko AS kategori, COUNT(*) AS jumlah,
         ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM dataset_hipertensi)) AS persen
  FROM dataset_hipertensi GROUP BY Kategori_Risiko;
"""

ATURAN = {"Tinggi": "Tekanan_Darah_Sistolik > 141.5",
          "Sedang": "Tekanan_Darah_Sistolik <= 141.5 dan > 119.5",
          "Rendah": "Tekanan_Darah_Sistolik <= 119.5"}


def main():
    k = konstanta_app()
    if DB.exists():
        DB.unlink()
    con = sqlite3.connect(DB)
    con.executescript(SCHEMA)

    with open(BASE / "Dataset_Hipertensi.csv", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    cols = list(rows[0].keys())
    con.executemany(f"INSERT INTO dataset_hipertensi ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})",
                    [[r[c] for c in cols] for r in rows])

    for r in reversed(json.loads((BASE / "riwayat.json").read_text("utf-8"))):
        g = r.get("gaya", {})
        con.execute("INSERT INTO riwayat_skrining VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (r["id"], r["tgl"], r["nama"], r["usia"], r["jk"], r["imt"], r["sis"], r["dia"], r["level"],
                     json.dumps(r["probs"], ensure_ascii=False), json.dumps(r["path"], ensure_ascii=False), r["n"],
                     json.dumps(r["tanda"], ensure_ascii=False), int(r["naik"]), r["bp"],
                     g.get("aktivitas"), g.get("merokok"), g.get("riwayat"), g.get("garam"), g.get("stres")))

    for kat, (rd, sd, tg) in k["LEAF"].items():
        con.execute("INSERT INTO model_decision_tree VALUES (?,?,?,?,?)", (kat, ATURAN[kat], rd, sd, tg))
    for kat, items in k["SARAN"].items():
        con.executemany("INSERT INTO saran (kategori,urutan,isi) VALUES (?,?,?)",
                        [(kat, i + 1, s) for i, s in enumerate(items)])
    con.executemany("INSERT INTO tanda_bahaya (nama) VALUES (?)", [(t,) for t in k["TANDA"]])
    con.executemany("INSERT INTO edukasi (judul,isi) VALUES (?,?)", k["EDU"])
    con.commit()

    SQL.write_text("\n".join(con.iterdump()) + "\n", "utf-8")
    for t in ("dataset_hipertensi", "riwayat_skrining", "model_decision_tree", "saran", "tanda_bahaya", "edukasi"):
        print(f"{t:22s}", con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0], "baris")
    con.close()
    print("Selesai:", DB)


if __name__ == "__main__":
    main()
