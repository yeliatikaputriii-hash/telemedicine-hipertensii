"""
TensiSehat - Teleskrining Risiko Hipertensi Keluarga (Streamlit)
Model : Decision Tree hasil RapidMiner pada Dataset_Hipertensi.csv (200 data)
Jalankan: streamlit run app.py   (Dataset_Hipertensi.csv harus satu folder dengan app.py)
"""
import html, json
from datetime import datetime
from pathlib import Path
import pandas as pd
import streamlit as st

BASE = Path(__file__).parent
CSV, DB = BASE / "Dataset_Hipertensi.csv", BASE / "riwayat.json"
st.set_page_config(page_title="TensiSehat", page_icon="🫀", layout="wide", initial_sidebar_state="collapsed")

# ---------------- Model dari RapidMiner ----------------
# Tekanan_Darah_Sistolik > 141.5 : Tinggi {Rendah=0, Tinggi=11, Sedang=0}
# Tekanan_Darah_Sistolik <= 141.5 dan > 119.5 : Sedang {Rendah=2, Tinggi=0, Sedang=77}
# Tekanan_Darah_Sistolik <= 119.5 : Rendah {Rendah=50, Tinggi=0, Sedang=0}
AKURASI = "98,33%"
LEAF = {"Tinggi": (0, 0, 11), "Sedang": (2, 77, 0), "Rendah": (50, 0, 0)}  # (Rendah, Sedang, Tinggi)

def predict(s):
    if s > 141.5: k, path = "Tinggi", ["Tekanan_Darah_Sistolik > 141.500"]
    elif s > 119.5: k, path = "Sedang", ["Tekanan_Darah_Sistolik ≤ 141.500", "Tekanan_Darah_Sistolik > 119.500"]
    else: k, path = "Rendah", ["Tekanan_Darah_Sistolik ≤ 141.500", "Tekanan_Darah_Sistolik ≤ 119.500"]
    c = LEAF[k]; n = sum(c)
    return k, {l: round(v / n * 100) for l, v in zip(("Rendah", "Sedang", "Tinggi"), c)}, path, n

def bp_class(s, d):
    if s >= 180 or d >= 120: return "Krisis hipertensi"
    if s >= 160 or d >= 100: return "Hipertensi derajat 2"
    if s >= 140 or d >= 90: return "Hipertensi derajat 1"
    if s >= 120 or d >= 80: return "Pra-hipertensi"
    return "Normal"

def imt_kat(i): return "Kurus" if i < 18.5 else "Normal" if i < 25 else "Berat badan lebih" if i < 30 else "Obesitas"

TANDA = ["Nyeri dada", "Sesak napas", "Sakit kepala mendadak", "Bicara pelo", "Lemah di satu sisi tubuh", "Pandangan kabur mendadak"]
SARAN = {
 "Rendah": ["Pertahankan pola hidup sehat: makan sayur dan buah, aktif bergerak, tidur cukup.", "Ukur tekanan darah secara berkala, misalnya setiap 6–12 bulan.", "Batasi garam, gula, dan makanan olahan."],
 "Sedang": ["Kurangi konsumsi garam dan makanan asin, perbanyak sayur dan buah.", "Bergerak aktif sekitar 150 menit per minggu dan jaga berat badan ideal.", "Hentikan kebiasaan merokok dan kelola stres.", "Ukur tekanan darah rutin; periksakan ke puskesmas bila ≥ 140/90 mmHg pada pengukuran berulang."],
 "Tinggi": ["Segera periksakan diri ke puskesmas, klinik, atau dokter untuk konfirmasi tekanan darah.", "Jangan mengobati sendiri dan jangan menghentikan obat yang sudah diresepkan tanpa saran dokter.", "Catat hasil ukur tekanan darah dan bawa riwayat ini saat berobat."]}
EDU = [("Apa itu hipertensi?", "Tekanan darah tinggi yang menetap, umumnya bila hasil ukur berulang ≥ 140/90 mmHg. Sering tanpa gejala sehingga disebut “silent killer”."),
 ("Faktor risiko", "Riwayat keluarga, usia lanjut, berat badan berlebih, kurang gerak, merokok, garam berlebih, dan stres."),
 ("Cara mengukur yang benar", "Duduk tenang 5 menit, punggung bersandar, kaki menapak lantai, lengan sejajar jantung, jangan merokok atau minum kopi 30 menit sebelumnya."),
 ("Pencegahan", "Kurangi garam, perbanyak sayur dan buah, olahraga teratur, tidak merokok, kelola stres, dan periksa tekanan darah rutin."),
 ("Kapan ke IGD?", "Tekanan darah ≥ 180/120 mmHg disertai nyeri dada, sesak, sakit kepala hebat, bicara pelo, atau lemah satu sisi tubuh.")]
EMOJI = {"Rendah": "😊", "Sedang": "😐", "Tinggi": "⚠️"}
WARNA = {"Rendah": "#22c55e", "Sedang": "#f97316", "Tinggi": "#ef4444"}

def load():
    try: return json.loads(DB.read_text("utf-8"))
    except Exception: return []
def save(rows): DB.write_text(json.dumps(rows, ensure_ascii=False, indent=1), "utf-8")
def go(p): st.session_state.page = p
def esc(t): return html.escape(str(t))

# ---------------- Tampilan (pink, sesuai desain Figma) ----------------
st.markdown("""<style>
#MainMenu,footer,header{visibility:hidden}
.stApp{background:#f5f5f5}.block-container{max-width:100%!important;padding:0 4vw 3rem!important}
.top{background:#ff6b8a;color:#fff;text-align:center;padding:16px;margin:0 -4vw 14px;line-height:1.4}.top b{font-size:24px}
.card{background:#fff;border:1px solid #f3c3d0;border-radius:14px;padding:16px;margin-bottom:14px;color:#2b1d22}
.hero{background:#ff6b8a;color:#fff;border:0}.hero h2{color:#fff;margin:0 0 8px}
.feat{background:#ffe1e9;border-radius:14px;padding:14px;color:#2b1d22;height:100%}.feat small{color:#7a6a70}
.row{display:flex;justify-content:space-between;font-weight:600;font-size:14px;margin:10px 0 3px}
.bar{height:12px;background:#e8e8e8;border-radius:8px;overflow:hidden}.bar i{display:block;height:100%}
.bd{display:inline-block;padding:3px 14px;border-radius:20px;font-weight:700}
.al{background:#fee2e2;color:#b91c1c;border-radius:10px;padding:10px;font-weight:600;margin:8px 0;font-size:14px}
.ds{background:#ffe1e9;color:#8a2b45;border-radius:12px;padding:12px;font-size:13px;text-align:center;margin-bottom:14px}
.dot{width:76px;height:76px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:38px}
.mut{color:#7a6a70;font-size:13px}.edu{background:#e4e4e4}
h2,h3,label,p,li{color:#2b1d22}
.stButton>button{border-radius:12px;font-weight:700;min-height:46px;border:0}
.stButton>button[kind="primary"],.stFormSubmitButton>button{background:#ff6b8a;color:#fff}
.stButton>button[kind="secondary"]{background:#ffe1e9;color:#e0486c}
.stButton>button:hover{filter:brightness(.95);color:#fff;background:#e0486c}
div[data-baseweb="input"],div[data-baseweb="select"]>div,div[data-baseweb="base-input"]{background:#ffe1e9!important;border-radius:10px!important;border:0!important}
div[data-baseweb="input"] input{background:transparent!important;color:#2b1d22!important}
.stCheckbox label span{color:#2b1d22!important}
</style>""", unsafe_allow_html=True)

def bars(items):
    return "".join(f'<div class="row"><span>{l}</span><span>{v}%</span></div><div class="bar"><i style="width:{v}%;background:{WARNA[l.split()[0]]}"></i></div>' for l, v in items)

# ---------------- Halaman ----------------
def beranda():
    st.markdown('<div class="card hero"><h2>Selamat datang</h2>TensiSehat membantu keluarga menilai kategori risiko hipertensi (Rendah, Sedang, Tinggi) dari faktor gaya hidup dan tekanan darah, memakai model Decision Tree yang dilatih dari dataset hipertensi.</div>', unsafe_allow_html=True)
    st.button("Mulai Skrining", type="primary", on_click=go, args=("Skrining",), key="mulai")
    f = [("Skrining Cerdas", "Decision Tree hasil RapidMiner"), ("Peringatan Darurat", "Tanda bahaya dan krisis tekanan darah"), ("Riwayat Keluarga", "Catatan per anggota keluarga"), ("Edukasi", "Panduan hipertensi singkat")]
    st.write("")
    for col, (t, d) in zip(st.columns(4), f):
        col.markdown(f'<div class="feat"><b>{t}</b><br><small>{d}</small></div>', unsafe_allow_html=True)
    st.write("")
    try:
        df = pd.read_csv(CSV); n = len(df); vc = df["Kategori_Risiko"].value_counts()
        rows = [(f"{k} ({int(vc.get(k, 0))} orang)", round(vc.get(k, 0) / n * 100)) for k in ("Rendah", "Sedang", "Tinggi")]
        st.markdown(f'<div class="card"><b>Distribusi kategori risiko pada dataset</b>{bars(rows)}<div class="mut" style="margin-top:8px">Total {n} data. Akurasi uji model RapidMiner: {AKURASI}.</div></div>', unsafe_allow_html=True)
    except Exception:
        st.warning("Dataset_Hipertensi.csv tidak ditemukan. Taruh satu folder dengan app.py.")
    st.markdown('<div class="ds">Data bersifat simulasi untuk latihan akademik. Hasil adalah informasi awal, bukan diagnosis dokter.</div>', unsafe_allow_html=True)

def skrining():
    st.header("Skrining Risiko")
    with st.form("form"):
        c = st.columns(3)
        nama = c[0].text_input("Nama anggota keluarga", placeholder="mis. Ayah")
        usia = c[1].number_input("Usia (tahun)", 1, 120, value=None, step=1, placeholder="Isi usia")
        jk = c[2].selectbox("Jenis kelamin", ["Laki-laki", "Perempuan"])
        c = st.columns(3)
        tb = c[0].number_input("Tinggi (cm)", 50.0, 250.0, value=None, step=0.5, placeholder="Isi tinggi")
        bb = c[1].number_input("Berat (kg)", 10.0, 300.0, value=None, step=0.5, placeholder="Isi berat")
        akt = c[2].selectbox("Aktivitas fisik", ["Rendah", "Sedang", "Tinggi"], index=1)
        c = st.columns(3)
        rok = c[0].selectbox("Merokok", ["Tidak", "Ya"])
        rw = c[1].selectbox("Riwayat keluarga hipertensi", ["Tidak", "Ya"])
        gar = c[2].selectbox("Konsumsi garam", ["Rendah", "Sedang", "Tinggi"], index=1)
        c = st.columns(3)
        strs = c[0].selectbox("Tingkat stres", ["Rendah", "Sedang", "Tinggi"], index=1)
        sis = c[1].number_input("Tekanan darah sistolik (mmHg) – wajib", 70, 260, value=None, step=1, placeholder="mis. 120")
        dia = c[2].number_input("Tekanan darah diastolik (mmHg)", 40, 160, value=None, step=1, placeholder="mis. 80")
        st.markdown("**Tanda bahaya saat ini**")
        cb = st.columns(3)
        tanda = [t for i, t in enumerate(TANDA) if cb[i % 3].checkbox(t, key=f"t{i}")]
        ok = st.form_submit_button("Analisis Risiko", use_container_width=True)
    if not ok: return
    if not nama.strip() or usia is None or tb is None or bb is None or sis is None:
        return st.error("Lengkapi nama, usia, tinggi, berat, dan tekanan sistolik (model RapidMiner memakai sistolik).")
    d = int(dia or 0)
    if d and sis <= d: return st.error("Tekanan sistolik harus lebih besar dari diastolik.")
    imt = round(bb / (tb / 100) ** 2, 1)
    lv, probs, path, n = predict(sis); bp = bp_class(sis, d)
    akhir = "Tinggi" if (tanda or bp == "Krisis hipertensi") else lv
    rows = load()
    rec = dict(id=(max([r["id"] for r in rows]) + 1) if rows else 1, tgl=datetime.now().strftime("%d/%m/%Y %H:%M"), nama=nama.strip(), usia=int(usia), jk=jk,
               imt=imt, sis=int(sis), dia=d, level=akhir, probs=probs, path=path, n=n, tanda=tanda, naik=akhir != lv, bp=bp,
               gaya=dict(aktivitas=akt, merokok=rok, riwayat=rw, garam=gar, stres=strs))
    save([rec] + rows); st.session_state.rid = rec["id"]; st.session_state.page = "Hasil"; st.rerun()

def hasil():
    r = next((x for x in load() if x["id"] == st.session_state.get("rid")), None)
    if not r: return go("Skrining") or st.rerun()
    lv = r["level"]; st.header(f"Hasil untuk {r['nama']}")
    a, b = st.columns(2)
    extra = (f'<div class="al">Tanda bahaya: {esc(", ".join(r["tanda"]))}. Segera ke IGD atau fasilitas kesehatan terdekat.</div>' if r["tanda"] else "") + \
            ('<div class="al">Tekanan darah sangat tinggi. Segera cari pertolongan medis.</div>' if r["bp"] == "Krisis hipertensi" else "") + \
            ('<div class="mut">Tingkat risiko dinaikkan oleh aturan pengaman (tanda bahaya / krisis hipertensi).</div>' if r["naik"] else "")
    a.markdown(f'''<div class="card" style="border-left:6px solid {WARNA[lv]}"><div style="display:flex;align-items:center;gap:14px">
<div class="dot" style="background:{WARNA[lv]}22">{EMOJI[lv]}</div><div><div class="mut">Tingkat risiko</div>
<span class="bd" style="background:{WARNA[lv]}22;color:{WARNA[lv]}">{lv}</span></div></div>{extra}
<h4 style="margin:14px 0 0">Probabilitas model (berdasarkan tekanan sistolik)</h4>{bars(list(r["probs"].items()))}
<p class="mut" style="margin-top:10px">IMT {r["imt"]} ({imt_kat(r["imt"])}) · Tekanan darah {r["sis"]}/{r["dia"] or "-"}: {r["bp"]}</p></div>''', unsafe_allow_html=True)
    b.markdown('<div class="card"><b>Saran tindak lanjut</b><ul>' + "".join(f"<li>{s}</li>" for s in SARAN[lv]) + "</ul></div>"
               f'<div class="card"><b>Jalur aturan pohon</b><div class="mut">{" → ".join(r["path"])} (daun berisi {r["n"]} data latih). Model RapidMiner memakai tekanan sistolik; akurasi uji {AKURASI}.</div></div>'
               '<div class="ds">Informasi awal berdasarkan data simulasi, bukan diagnosis. Konsultasikan dengan tenaga kesehatan.</div>', unsafe_allow_html=True)
    b.button("Lihat Riwayat", type="primary", on_click=go, args=("Riwayat",), use_container_width=True, key="lr")
    b.button("Skrining Baru", on_click=go, args=("Skrining",), use_container_width=True, key="sb")

def riwayat():
    st.header("Riwayat Skrining"); rows = load()
    if not rows: return st.markdown('<div class="card">Belum ada riwayat. Lakukan skrining terlebih dahulu.</div>', unsafe_allow_html=True)
    pilih = st.radio("Anggota keluarga", ["Semua"] + sorted({r["nama"] for r in rows}), horizontal=True)
    tampil = [r for r in rows if pilih == "Semua" or r["nama"] == pilih]
    cols = st.columns(3)
    for i, r in enumerate(tampil):
        with cols[i % 3]:
            st.markdown(f'<div class="card" style="border-left:6px solid {WARNA[r["level"]]};margin-bottom:6px"><div class="row" style="margin:0"><b>{esc(r["nama"])} ({r["usia"]} th)</b>'
                        f'<span class="bd" style="background:{WARNA[r["level"]]}22;color:{WARNA[r["level"]]}">{r["level"]}</span></div>'
                        f'<div class="mut">{r["tgl"]} · IMT {r["imt"]} · TD {r["sis"]}/{r["dia"] or "-"} · {r["bp"]}</div></div>', unsafe_allow_html=True)
            st.button("Lihat detail", key=f"d{r['id']}", on_click=lambda x=r["id"]: st.session_state.update(rid=x, page="Hasil"), use_container_width=True)
    st.write("")
    if st.session_state.get("hapus"):
        st.warning("Hapus semua riwayat?")
        c = st.columns(2)
        if c[0].button("Ya, hapus", type="primary", use_container_width=True): save([]); st.session_state.hapus = False; st.rerun()
        if c[1].button("Batal", use_container_width=True): st.session_state.hapus = False; st.rerun()
    else:
        st.button("Hapus Riwayat", on_click=lambda: st.session_state.update(hapus=True))

def edukasi():
    st.header("Edukasi Hipertensi")
    cols = st.columns(2)
    for i, (t, d) in enumerate(EDU):
        cols[i % 2].markdown(f'<div class="card edu"><b>{t}</b><br>{d}</div>', unsafe_allow_html=True)
    st.markdown('<div class="ds">Materi bersifat edukasi umum dan perlu divalidasi tenaga kesehatan.</div>', unsafe_allow_html=True)

# ---------------- Navigasi ----------------
st.session_state.setdefault("page", "Beranda")
st.markdown('<div class="top"><b>TensiSehat</b><br>Skrining Risiko Hipertensi untuk Keluarga</div>', unsafe_allow_html=True)
aktif = "Skrining" if st.session_state.page == "Hasil" else st.session_state.page
for col, p in zip(st.columns(4), ["Beranda", "Skrining", "Riwayat", "Edukasi"]):
    col.button(p, key=f"nav_{p}", type="primary" if p == aktif else "secondary", on_click=go, args=(p,), use_container_width=True)
st.write("")
{"Beranda": beranda, "Skrining": skrining, "Hasil": hasil, "Riwayat": riwayat, "Edukasi": edukasi}[st.session_state.page]()
