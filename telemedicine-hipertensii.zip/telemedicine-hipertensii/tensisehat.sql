BEGIN TRANSACTION;
CREATE TABLE dataset_hipertensi (
  ID_Pasien TEXT PRIMARY KEY,
  Usia INTEGER NOT NULL,
  Jenis_Kelamin TEXT NOT NULL,
  IMT REAL NOT NULL,
  Aktivitas_Fisik TEXT NOT NULL,
  Merokok TEXT NOT NULL,
  Riwayat_Keluarga_Hipertensi TEXT NOT NULL,
  Konsumsi_Garam TEXT NOT NULL,
  Tingkat_Stres TEXT NOT NULL,
  Tekanan_Darah_Sistolik INTEGER NOT NULL,
  Tekanan_Darah_Diastolik INTEGER NOT NULL,
  Kategori_Risiko TEXT NOT NULL CHECK (Kategori_Risiko IN ('Rendah','Sedang','Tinggi'))
);
INSERT INTO "dataset_hipertensi" VALUES('P001',24,'Laki-laki',28.2,'Rendah','Tidak','Tidak','Sedang','Sedang',113,78,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P002',63,'Perempuan',23.8,'Tinggi','Tidak','Tidak','Rendah','Sedang',107,80,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P003',56,'Laki-laki',25.5,'Rendah','Ya','Ya','Sedang','Sedang',159,92,'Tinggi');
INSERT INTO "dataset_hipertensi" VALUES('P004',44,'Perempuan',24.8,'Rendah','Tidak','Tidak','Tinggi','Sedang',119,77,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P005',44,'Laki-laki',26.9,'Rendah','Tidak','Tidak','Sedang','Sedang',106,73,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P006',68,'Laki-laki',31.4,'Sedang','Tidak','Tidak','Rendah','Sedang',128,85,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P007',24,'Perempuan',25.9,'Rendah','Ya','Tidak','Tinggi','Sedang',140,89,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P008',59,'Perempuan',28.2,'Tinggi','Ya','Ya','Sedang','Tinggi',146,110,'Tinggi');
INSERT INTO "dataset_hipertensi" VALUES('P009',31,'Laki-laki',16.9,'Sedang','Tidak','Ya','Rendah','Tinggi',129,87,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P010',25,'Perempuan',25.3,'Rendah','Tidak','Tidak','Sedang','Tinggi',116,72,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P011',49,'Laki-laki',22.0,'Rendah','Tidak','Ya','Rendah','Rendah',129,85,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P012',74,'Perempuan',20.4,'Rendah','Tidak','Tidak','Sedang','Sedang',138,84,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P013',61,'Perempuan',21.8,'Sedang','Tidak','Tidak','Sedang','Tinggi',125,83,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P014',62,'Laki-laki',24.1,'Tinggi','Tidak','Ya','Sedang','Rendah',124,84,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P015',60,'Perempuan',29.3,'Rendah','Tidak','Tidak','Rendah','Sedang',122,80,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P016',64,'Laki-laki',19.9,'Tinggi','Ya','Ya','Sedang','Sedang',135,80,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P017',48,'Laki-laki',25.6,'Rendah','Tidak','Tidak','Sedang','Rendah',111,77,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P018',27,'Laki-laki',23.5,'Tinggi','Tidak','Ya','Sedang','Tinggi',135,84,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P019',67,'Laki-laki',24.1,'Tinggi','Tidak','Tidak','Sedang','Tinggi',124,90,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P020',45,'Perempuan',29.7,'Sedang','Tidak','Tidak','Sedang','Sedang',117,74,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P021',48,'Laki-laki',27.8,'Sedang','Ya','Tidak','Sedang','Tinggi',121,80,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P022',40,'Laki-laki',31.1,'Tinggi','Tidak','Tidak','Rendah','Sedang',106,67,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P023',30,'Perempuan',24.9,'Rendah','Ya','Tidak','Sedang','Tinggi',138,82,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P024',71,'Laki-laki',22.6,'Rendah','Ya','Tidak','Sedang','Tinggi',125,90,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P025',63,'Perempuan',24.6,'Rendah','Tidak','Tidak','Sedang','Tinggi',137,82,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P026',56,'Laki-laki',26.5,'Sedang','Tidak','Tidak','Sedang','Sedang',108,73,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P027',42,'Perempuan',26.2,'Sedang','Tidak','Tidak','Sedang','Tinggi',113,79,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P028',66,'Perempuan',20.9,'Sedang','Tidak','Tidak','Tinggi','Tinggi',138,90,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P029',50,'Perempuan',25.9,'Tinggi','Tidak','Ya','Tinggi','Rendah',120,82,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P030',44,'Laki-laki',26.5,'Rendah','Tidak','Tidak','Sedang','Sedang',111,65,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P031',45,'Laki-laki',36.1,'Sedang','Ya','Tidak','Sedang','Sedang',107,67,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P032',32,'Perempuan',33.4,'Rendah','Ya','Tidak','Sedang','Tinggi',139,80,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P033',25,'Laki-laki',21.9,'Rendah','Tidak','Ya','Tinggi','Sedang',123,82,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P034',51,'Perempuan',24.3,'Sedang','Tidak','Tidak','Sedang','Sedang',103,74,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P035',69,'Laki-laki',19.4,'Tinggi','Ya','Tidak','Tinggi','Sedang',127,90,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P036',23,'Perempuan',23.0,'Sedang','Tidak','Tidak','Sedang','Tinggi',105,73,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P037',68,'Perempuan',26.8,'Rendah','Tidak','Ya','Rendah','Rendah',133,86,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P038',66,'Laki-laki',30.6,'Sedang','Ya','Tidak','Tinggi','Rendah',136,82,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P039',35,'Laki-laki',22.4,'Rendah','Tidak','Ya','Sedang','Tinggi',130,88,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P040',55,'Perempuan',22.8,'Tinggi','Tidak','Ya','Tinggi','Tinggi',166,102,'Tinggi');
INSERT INTO "dataset_hipertensi" VALUES('P041',29,'Laki-laki',16.5,'Sedang','Tidak','Tidak','Tinggi','Tinggi',113,78,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P042',62,'Perempuan',24.8,'Rendah','Ya','Tidak','Tinggi','Sedang',133,90,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P043',59,'Laki-laki',21.0,'Rendah','Tidak','Ya','Tinggi','Tinggi',143,97,'Tinggi');
INSERT INTO "dataset_hipertensi" VALUES('P044',39,'Perempuan',23.3,'Rendah','Tidak','Tidak','Sedang','Rendah',102,66,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P045',23,'Perempuan',21.8,'Tinggi','Tidak','Tidak','Rendah','Rendah',109,68,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P046',74,'Laki-laki',25.1,'Sedang','Ya','Tidak','Tinggi','Rendah',128,84,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P047',44,'Perempuan',18.1,'Sedang','Tidak','Tidak','Sedang','Sedang',113,80,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P048',70,'Laki-laki',19.3,'Sedang','Tidak','Tidak','Sedang','Rendah',117,71,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P049',57,'Perempuan',34.4,'Sedang','Ya','Tidak','Rendah','Tinggi',126,88,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P050',63,'Laki-laki',20.1,'Rendah','Tidak','Tidak','Sedang','Sedang',122,85,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P051',62,'Laki-laki',20.9,'Tinggi','Ya','Tidak','Tinggi','Sedang',128,82,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P052',30,'Laki-laki',33.2,'Rendah','Ya','Tidak','Sedang','Rendah',132,83,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P053',40,'Laki-laki',37.7,'Sedang','Tidak','Ya','Sedang','Sedang',123,87,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P054',46,'Laki-laki',20.6,'Sedang','Tidak','Tidak','Rendah','Rendah',103,75,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P055',47,'Perempuan',24.0,'Sedang','Tidak','Tidak','Sedang','Tinggi',103,71,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P056',22,'Laki-laki',26.9,'Tinggi','Tidak','Tidak','Sedang','Rendah',116,68,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P057',50,'Perempuan',32.8,'Rendah','Ya','Ya','Tinggi','Sedang',163,105,'Tinggi');
INSERT INTO "dataset_hipertensi" VALUES('P058',28,'Laki-laki',21.4,'Sedang','Tidak','Ya','Sedang','Sedang',118,67,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P059',61,'Laki-laki',24.5,'Rendah','Ya','Tidak','Rendah','Rendah',135,90,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P060',58,'Perempuan',28.8,'Sedang','Tidak','Ya','Sedang','Sedang',136,82,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P061',71,'Perempuan',27.3,'Rendah','Tidak','Tidak','Sedang','Sedang',137,81,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P062',61,'Laki-laki',23.9,'Rendah','Tidak','Tidak','Rendah','Sedang',132,85,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P063',40,'Laki-laki',24.9,'Rendah','Tidak','Tidak','Rendah','Tinggi',111,73,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P064',74,'Perempuan',19.7,'Rendah','Tidak','Tidak','Sedang','Sedang',120,85,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P065',43,'Perempuan',24.5,'Sedang','Tidak','Tidak','Sedang','Tinggi',119,71,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P066',38,'Perempuan',24.4,'Sedang','Tidak','Ya','Sedang','Tinggi',125,90,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P067',70,'Laki-laki',26.5,'Sedang','Ya','Tidak','Sedang','Rendah',122,85,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P068',40,'Laki-laki',23.2,'Rendah','Tidak','Tidak','Sedang','Sedang',110,72,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P069',24,'Perempuan',27.5,'Rendah','Ya','Tidak','Tinggi','Sedang',139,84,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P070',46,'Perempuan',29.8,'Rendah','Ya','Tidak','Rendah','Sedang',140,80,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P071',64,'Laki-laki',26.2,'Sedang','Ya','Tidak','Rendah','Sedang',135,86,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P072',30,'Laki-laki',27.0,'Rendah','Tidak','Tidak','Rendah','Sedang',105,68,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P073',45,'Laki-laki',25.7,'Rendah','Tidak','Ya','Rendah','Rendah',135,87,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P074',27,'Perempuan',25.5,'Rendah','Tidak','Tidak','Sedang','Rendah',112,65,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P075',58,'Laki-laki',22.5,'Sedang','Tidak','Tidak','Sedang','Sedang',112,80,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P076',46,'Laki-laki',26.8,'Rendah','Tidak','Ya','Sedang','Sedang',120,85,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P077',38,'Laki-laki',25.1,'Sedang','Tidak','Ya','Sedang','Sedang',110,79,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P078',32,'Perempuan',34.3,'Sedang','Tidak','Tidak','Sedang','Sedang',105,72,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P079',51,'Laki-laki',32.1,'Sedang','Ya','Ya','Tinggi','Sedang',135,80,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P080',57,'Laki-laki',27.1,'Sedang','Tidak','Tidak','Sedang','Sedang',136,89,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P081',72,'Laki-laki',22.3,'Sedang','Ya','Ya','Tinggi','Sedang',162,103,'Tinggi');
INSERT INTO "dataset_hipertensi" VALUES('P082',44,'Laki-laki',20.8,'Rendah','Tidak','Ya','Tinggi','Sedang',135,88,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P083',28,'Perempuan',30.5,'Sedang','Tidak','Tidak','Sedang','Sedang',118,71,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P084',66,'Laki-laki',26.6,'Sedang','Tidak','Tidak','Sedang','Sedang',109,75,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P085',55,'Laki-laki',27.5,'Sedang','Tidak','Ya','Tinggi','Tinggi',145,107,'Tinggi');
INSERT INTO "dataset_hipertensi" VALUES('P086',59,'Perempuan',18.2,'Sedang','Tidak','Ya','Rendah','Tinggi',136,86,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P087',25,'Laki-laki',29.4,'Rendah','Tidak','Ya','Rendah','Sedang',126,83,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P088',37,'Perempuan',27.4,'Sedang','Ya','Tidak','Tinggi','Sedang',129,87,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P089',62,'Perempuan',20.8,'Sedang','Ya','Tidak','Tinggi','Tinggi',136,87,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P090',66,'Laki-laki',23.5,'Tinggi','Tidak','Ya','Sedang','Sedang',139,90,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P091',44,'Perempuan',26.6,'Tinggi','Ya','Ya','Rendah','Rendah',134,84,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P092',65,'Laki-laki',25.7,'Sedang','Tidak','Tidak','Rendah','Sedang',112,71,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P093',67,'Perempuan',24.3,'Sedang','Ya','Tidak','Tinggi','Rendah',133,88,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P094',41,'Laki-laki',25.1,'Sedang','Tidak','Tidak','Sedang','Rendah',107,73,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P095',70,'Perempuan',24.4,'Rendah','Tidak','Tidak','Tinggi','Sedang',120,88,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P096',36,'Perempuan',26.1,'Tinggi','Tidak','Ya','Sedang','Sedang',110,72,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P097',33,'Perempuan',31.7,'Sedang','Tidak','Ya','Rendah','Tinggi',131,82,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P098',58,'Laki-laki',16.0,'Rendah','Tidak','Ya','Tinggi','Rendah',158,105,'Tinggi');
INSERT INTO "dataset_hipertensi" VALUES('P099',55,'Laki-laki',24.5,'Rendah','Tidak','Tidak','Tinggi','Sedang',127,81,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P100',27,'Laki-laki',26.2,'Tinggi','Tidak','Tidak','Sedang','Rendah',108,68,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P101',66,'Laki-laki',26.7,'Rendah','Tidak','Tidak','Sedang','Sedang',127,86,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P102',31,'Perempuan',23.9,'Rendah','Tidak','Tidak','Rendah','Tinggi',102,76,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P103',65,'Laki-laki',18.1,'Rendah','Tidak','Tidak','Rendah','Tinggi',124,89,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P104',20,'Perempuan',26.9,'Rendah','Ya','Tidak','Tinggi','Sedang',135,82,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P105',64,'Perempuan',32.8,'Rendah','Tidak','Ya','Tinggi','Sedang',157,92,'Tinggi');
INSERT INTO "dataset_hipertensi" VALUES('P106',64,'Laki-laki',19.1,'Sedang','Ya','Ya','Rendah','Tinggi',143,110,'Tinggi');
INSERT INTO "dataset_hipertensi" VALUES('P107',63,'Laki-laki',29.1,'Rendah','Tidak','Ya','Tinggi','Sedang',164,93,'Tinggi');
INSERT INTO "dataset_hipertensi" VALUES('P108',57,'Perempuan',24.1,'Tinggi','Tidak','Tidak','Rendah','Rendah',105,68,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P109',46,'Laki-laki',25.2,'Tinggi','Tidak','Ya','Sedang','Sedang',108,69,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P110',59,'Laki-laki',21.1,'Rendah','Tidak','Tidak','Tinggi','Sedang',126,85,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P111',35,'Perempuan',24.1,'Rendah','Ya','Tidak','Rendah','Tinggi',123,89,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P112',63,'Perempuan',31.0,'Sedang','Tidak','Tidak','Tinggi','Rendah',135,88,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P113',51,'Laki-laki',27.9,'Rendah','Ya','Ya','Sedang','Sedang',123,87,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P114',45,'Laki-laki',32.8,'Rendah','Ya','Ya','Sedang','Rendah',137,81,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P115',48,'Laki-laki',30.4,'Tinggi','Ya','Ya','Sedang','Sedang',135,83,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P116',51,'Perempuan',27.3,'Tinggi','Ya','Tidak','Sedang','Sedang',116,72,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P117',22,'Perempuan',32.8,'Sedang','Tidak','Tidak','Sedang','Sedang',116,67,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P118',27,'Perempuan',27.3,'Rendah','Tidak','Tidak','Rendah','Tinggi',128,83,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P119',33,'Perempuan',29.0,'Sedang','Ya','Ya','Rendah','Rendah',125,83,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P120',26,'Perempuan',24.3,'Sedang','Ya','Tidak','Sedang','Sedang',108,67,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P121',44,'Laki-laki',25.8,'Rendah','Ya','Tidak','Tinggi','Sedang',134,86,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P122',57,'Laki-laki',22.6,'Sedang','Tidak','Tidak','Sedang','Rendah',117,76,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P123',56,'Perempuan',29.7,'Rendah','Ya','Tidak','Rendah','Rendah',123,80,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P124',46,'Perempuan',20.6,'Rendah','Tidak','Ya','Sedang','Rendah',128,85,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P125',67,'Perempuan',28.8,'Sedang','Ya','Tidak','Sedang','Tinggi',125,88,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P126',51,'Laki-laki',24.7,'Rendah','Ya','Ya','Sedang','Sedang',132,88,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P127',24,'Laki-laki',30.4,'Rendah','Tidak','Tidak','Tinggi','Rendah',122,88,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P128',62,'Laki-laki',28.7,'Tinggi','Tidak','Ya','Sedang','Sedang',124,84,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P129',52,'Laki-laki',33.1,'Tinggi','Ya','Ya','Sedang','Tinggi',129,89,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P130',55,'Perempuan',28.6,'Sedang','Ya','Tidak','Rendah','Rendah',125,82,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P131',51,'Perempuan',18.9,'Tinggi','Tidak','Ya','Rendah','Sedang',107,70,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P132',51,'Laki-laki',25.2,'Tinggi','Ya','Tidak','Rendah','Sedang',103,67,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P133',25,'Laki-laki',20.6,'Rendah','Tidak','Tidak','Sedang','Rendah',104,72,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P134',51,'Perempuan',23.3,'Sedang','Tidak','Ya','Sedang','Sedang',107,71,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P135',64,'Laki-laki',31.8,'Rendah','Tidak','Tidak','Sedang','Sedang',135,82,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P136',37,'Perempuan',28.2,'Rendah','Tidak','Tidak','Rendah','Sedang',119,77,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P137',53,'Perempuan',22.6,'Sedang','Tidak','Tidak','Sedang','Sedang',103,70,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P138',21,'Laki-laki',21.2,'Sedang','Tidak','Ya','Rendah','Tinggi',123,83,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P139',39,'Laki-laki',25.6,'Sedang','Ya','Tidak','Tinggi','Rendah',107,67,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P140',44,'Perempuan',20.4,'Rendah','Tidak','Ya','Rendah','Rendah',120,84,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P141',75,'Perempuan',22.7,'Rendah','Ya','Ya','Tinggi','Sedang',161,96,'Tinggi');
INSERT INTO "dataset_hipertensi" VALUES('P142',32,'Laki-laki',26.8,'Tinggi','Tidak','Ya','Tinggi','Sedang',138,84,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P143',35,'Perempuan',30.4,'Rendah','Tidak','Tidak','Sedang','Rendah',118,68,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P144',42,'Perempuan',28.1,'Rendah','Ya','Tidak','Tinggi','Tinggi',131,88,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P145',75,'Perempuan',16.0,'Rendah','Tidak','Tidak','Tinggi','Sedang',121,90,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P146',67,'Laki-laki',26.8,'Sedang','Tidak','Tidak','Tinggi','Sedang',127,85,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P147',21,'Perempuan',25.8,'Sedang','Ya','Tidak','Sedang','Sedang',113,75,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P148',33,'Perempuan',27.2,'Sedang','Tidak','Tidak','Sedang','Tinggi',100,78,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P149',66,'Laki-laki',32.3,'Rendah','Tidak','Tidak','Tinggi','Sedang',133,90,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P150',23,'Laki-laki',16.8,'Rendah','Ya','Tidak','Sedang','Sedang',109,74,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P151',67,'Perempuan',23.0,'Tinggi','Ya','Ya','Rendah','Sedang',129,89,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P152',35,'Laki-laki',28.0,'Sedang','Ya','Ya','Tinggi','Tinggi',165,109,'Tinggi');
INSERT INTO "dataset_hipertensi" VALUES('P153',71,'Laki-laki',18.9,'Sedang','Tidak','Tidak','Tinggi','Sedang',130,88,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P154',36,'Laki-laki',31.7,'Sedang','Ya','Tidak','Rendah','Sedang',107,72,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P155',44,'Perempuan',27.0,'Sedang','Ya','Tidak','Rendah','Tinggi',135,80,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P156',57,'Perempuan',29.1,'Rendah','Ya','Ya','Sedang','Tinggi',162,90,'Tinggi');
INSERT INTO "dataset_hipertensi" VALUES('P157',27,'Laki-laki',23.1,'Rendah','Ya','Tidak','Rendah','Tinggi',132,85,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P158',51,'Perempuan',28.9,'Sedang','Tidak','Ya','Tinggi','Sedang',129,85,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P159',48,'Laki-laki',30.0,'Rendah','Ya','Ya','Sedang','Tinggi',155,98,'Tinggi');
INSERT INTO "dataset_hipertensi" VALUES('P160',63,'Perempuan',26.5,'Tinggi','Tidak','Ya','Sedang','Rendah',129,86,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P161',75,'Perempuan',26.5,'Sedang','Tidak','Ya','Tinggi','Sedang',136,86,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P162',57,'Perempuan',26.6,'Sedang','Tidak','Tidak','Sedang','Rendah',113,78,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P163',42,'Laki-laki',21.9,'Tinggi','Ya','Ya','Sedang','Rendah',140,81,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P164',42,'Perempuan',24.9,'Sedang','Tidak','Tidak','Sedang','Tinggi',114,68,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P165',43,'Laki-laki',24.9,'Tinggi','Tidak','Tidak','Sedang','Sedang',104,77,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P166',65,'Perempuan',27.1,'Sedang','Ya','Tidak','Sedang','Rendah',121,89,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P167',37,'Laki-laki',29.7,'Tinggi','Tidak','Tidak','Tinggi','Sedang',116,80,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P168',29,'Laki-laki',21.1,'Rendah','Tidak','Ya','Tinggi','Sedang',134,89,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P169',38,'Laki-laki',25.0,'Sedang','Ya','Tidak','Sedang','Sedang',102,79,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P170',21,'Perempuan',31.7,'Sedang','Tidak','Tidak','Tinggi','Tinggi',123,83,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P171',25,'Laki-laki',22.4,'Rendah','Tidak','Tidak','Tinggi','Sedang',102,71,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P172',25,'Perempuan',22.0,'Rendah','Tidak','Tidak','Tinggi','Rendah',115,69,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P173',63,'Laki-laki',26.3,'Tinggi','Tidak','Ya','Tinggi','Rendah',137,86,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P174',60,'Laki-laki',29.0,'Sedang','Tidak','Tidak','Rendah','Tinggi',133,90,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P175',59,'Perempuan',25.5,'Rendah','Tidak','Ya','Sedang','Sedang',129,83,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P176',45,'Laki-laki',31.1,'Rendah','Ya','Ya','Rendah','Sedang',140,86,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P177',60,'Perempuan',29.1,'Rendah','Tidak','Ya','Tinggi','Rendah',159,96,'Tinggi');
INSERT INTO "dataset_hipertensi" VALUES('P178',29,'Perempuan',29.0,'Rendah','Tidak','Tidak','Sedang','Tinggi',124,81,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P179',70,'Laki-laki',27.8,'Tinggi','Ya','Tidak','Sedang','Rendah',124,82,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P180',48,'Laki-laki',35.3,'Sedang','Tidak','Tidak','Sedang','Rendah',115,65,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P181',72,'Laki-laki',24.6,'Rendah','Ya','Tidak','Rendah','Tinggi',133,90,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P182',28,'Perempuan',17.1,'Sedang','Ya','Ya','Rendah','Tinggi',136,84,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P183',47,'Perempuan',32.2,'Rendah','Ya','Tidak','Rendah','Rendah',121,89,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P184',58,'Laki-laki',23.6,'Rendah','Tidak','Tidak','Tinggi','Tinggi',120,87,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P185',47,'Laki-laki',26.0,'Sedang','Ya','Tidak','Tinggi','Sedang',114,68,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P186',44,'Laki-laki',31.0,'Sedang','Ya','Ya','Sedang','Rendah',135,81,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P187',29,'Laki-laki',18.8,'Tinggi','Tidak','Tidak','Tinggi','Sedang',104,77,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P188',41,'Perempuan',20.2,'Sedang','Tidak','Ya','Sedang','Sedang',120,69,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P189',33,'Perempuan',18.8,'Sedang','Tidak','Ya','Sedang','Sedang',119,79,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P190',36,'Laki-laki',22.2,'Sedang','Ya','Tidak','Sedang','Tinggi',116,67,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P191',58,'Perempuan',27.3,'Tinggi','Tidak','Ya','Rendah','Rendah',126,87,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P192',55,'Laki-laki',27.7,'Sedang','Tidak','Ya','Sedang','Sedang',140,88,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P193',54,'Laki-laki',26.7,'Tinggi','Ya','Tidak','Tinggi','Tinggi',128,82,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P194',40,'Perempuan',19.6,'Sedang','Ya','Tidak','Tinggi','Sedang',120,69,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P195',73,'Perempuan',16.0,'Tinggi','Tidak','Tidak','Sedang','Rendah',107,80,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P196',24,'Perempuan',25.7,'Rendah','Ya','Ya','Sedang','Tinggi',131,82,'Sedang');
INSERT INTO "dataset_hipertensi" VALUES('P197',39,'Laki-laki',23.5,'Sedang','Tidak','Tidak','Tinggi','Rendah',100,71,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P198',26,'Laki-laki',27.4,'Sedang','Tidak','Tidak','Sedang','Sedang',120,71,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P199',38,'Laki-laki',28.4,'Sedang','Ya','Tidak','Sedang','Rendah',114,69,'Rendah');
INSERT INTO "dataset_hipertensi" VALUES('P200',73,'Laki-laki',26.1,'Sedang','Ya','Tidak','Rendah','Rendah',136,88,'Sedang');
CREATE TABLE edukasi (id INTEGER PRIMARY KEY AUTOINCREMENT, judul TEXT NOT NULL, isi TEXT NOT NULL);
INSERT INTO "edukasi" VALUES(1,'Apa itu hipertensi?','Tekanan darah tinggi yang menetap, umumnya bila hasil ukur berulang ≥ 140/90 mmHg. Sering tanpa gejala sehingga disebut “silent killer”.');
INSERT INTO "edukasi" VALUES(2,'Faktor risiko','Riwayat keluarga, usia lanjut, berat badan berlebih, kurang gerak, merokok, garam berlebih, dan stres.');
INSERT INTO "edukasi" VALUES(3,'Cara mengukur yang benar','Duduk tenang 5 menit, punggung bersandar, kaki menapak lantai, lengan sejajar jantung, jangan merokok atau minum kopi 30 menit sebelumnya.');
INSERT INTO "edukasi" VALUES(4,'Pencegahan','Kurangi garam, perbanyak sayur dan buah, olahraga teratur, tidak merokok, kelola stres, dan periksa tekanan darah rutin.');
INSERT INTO "edukasi" VALUES(5,'Kapan ke IGD?','Tekanan darah ≥ 180/120 mmHg disertai nyeri dada, sesak, sakit kepala hebat, bicara pelo, atau lemah satu sisi tubuh.');
CREATE TABLE model_decision_tree (
  kategori TEXT PRIMARY KEY,
  aturan TEXT NOT NULL,
  jumlah_rendah INTEGER NOT NULL,
  jumlah_sedang INTEGER NOT NULL,
  jumlah_tinggi INTEGER NOT NULL
);
INSERT INTO "model_decision_tree" VALUES('Tinggi','Tekanan_Darah_Sistolik > 141.5',0,0,11);
INSERT INTO "model_decision_tree" VALUES('Sedang','Tekanan_Darah_Sistolik <= 141.5 dan > 119.5',2,77,0);
INSERT INTO "model_decision_tree" VALUES('Rendah','Tekanan_Darah_Sistolik <= 119.5',50,0,0);
CREATE TABLE riwayat_skrining (
  id INTEGER PRIMARY KEY,
  tgl TEXT NOT NULL,
  nama TEXT NOT NULL,
  usia INTEGER NOT NULL,
  jk TEXT NOT NULL,
  imt REAL NOT NULL,
  sis INTEGER NOT NULL,
  dia INTEGER NOT NULL,
  level TEXT NOT NULL CHECK (level IN ('Rendah','Sedang','Tinggi')),
  probs TEXT NOT NULL,          -- JSON {"Rendah":..,"Sedang":..,"Tinggi":..}
  path TEXT NOT NULL,           -- JSON daftar aturan pohon
  n INTEGER NOT NULL,
  tanda TEXT NOT NULL,          -- JSON daftar tanda bahaya
  naik INTEGER NOT NULL,        -- 1 bila dinaikkan aturan pengaman
  bp TEXT NOT NULL,
  aktivitas TEXT, merokok TEXT, riwayat TEXT, garam TEXT, stres TEXT   -- isi objek "gaya"
);
INSERT INTO "riwayat_skrining" VALUES(1,'21/11/2026 22:56','naasrul',56,'Laki-laki',22.0,120,80,'Tinggi','{"Rendah": 3, "Sedang": 97, "Tinggi": 0}','["Tekanan_Darah_Sistolik ≤ 141.500", "Tekanan_Darah_Sistolik > 119.500"]',79,'["Nyeri dada"]',1,'Pra-hipertensi','Tinggi','Ya','Ya','Tinggi','Tinggi');
CREATE TABLE saran (id INTEGER PRIMARY KEY AUTOINCREMENT, kategori TEXT NOT NULL, urutan INTEGER NOT NULL, isi TEXT NOT NULL);
INSERT INTO "saran" VALUES(1,'Rendah',1,'Pertahankan pola hidup sehat: makan sayur dan buah, aktif bergerak, tidur cukup.');
INSERT INTO "saran" VALUES(2,'Rendah',2,'Ukur tekanan darah secara berkala, misalnya setiap 6–12 bulan.');
INSERT INTO "saran" VALUES(3,'Rendah',3,'Batasi garam, gula, dan makanan olahan.');
INSERT INTO "saran" VALUES(4,'Sedang',1,'Kurangi konsumsi garam dan makanan asin, perbanyak sayur dan buah.');
INSERT INTO "saran" VALUES(5,'Sedang',2,'Bergerak aktif sekitar 150 menit per minggu dan jaga berat badan ideal.');
INSERT INTO "saran" VALUES(6,'Sedang',3,'Hentikan kebiasaan merokok dan kelola stres.');
INSERT INTO "saran" VALUES(7,'Sedang',4,'Ukur tekanan darah rutin; periksakan ke puskesmas bila ≥ 140/90 mmHg pada pengukuran berulang.');
INSERT INTO "saran" VALUES(8,'Tinggi',1,'Segera periksakan diri ke puskesmas, klinik, atau dokter untuk konfirmasi tekanan darah.');
INSERT INTO "saran" VALUES(9,'Tinggi',2,'Jangan mengobati sendiri dan jangan menghentikan obat yang sudah diresepkan tanpa saran dokter.');
INSERT INTO "saran" VALUES(10,'Tinggi',3,'Catat hasil ukur tekanan darah dan bawa riwayat ini saat berobat.');
CREATE TABLE tanda_bahaya (id INTEGER PRIMARY KEY AUTOINCREMENT, nama TEXT NOT NULL UNIQUE);
INSERT INTO "tanda_bahaya" VALUES(1,'Nyeri dada');
INSERT INTO "tanda_bahaya" VALUES(2,'Sesak napas');
INSERT INTO "tanda_bahaya" VALUES(3,'Sakit kepala mendadak');
INSERT INTO "tanda_bahaya" VALUES(4,'Bicara pelo');
INSERT INTO "tanda_bahaya" VALUES(5,'Lemah di satu sisi tubuh');
INSERT INTO "tanda_bahaya" VALUES(6,'Pandangan kabur mendadak');
CREATE INDEX idx_riwayat_nama ON riwayat_skrining(nama);
CREATE VIEW v_distribusi_kategori AS
  SELECT Kategori_Risiko AS kategori, COUNT(*) AS jumlah,
         ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM dataset_hipertensi)) AS persen
  FROM dataset_hipertensi GROUP BY Kategori_Risiko;
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('saran',10);
INSERT INTO "sqlite_sequence" VALUES('tanda_bahaya',6);
INSERT INTO "sqlite_sequence" VALUES('edukasi',5);
COMMIT;
